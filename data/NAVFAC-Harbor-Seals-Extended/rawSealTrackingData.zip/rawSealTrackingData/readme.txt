Read Me:
Data Contact:  
Gwen Lockhart
Natural Resource Specialist (EV53)
Navy Facilities Engineering Command Atlantic
gwendolyn.lockhart@navy.mil
757.322.8265

Data Purpose: Density model validation
Data Project: NAVFAC Atlantic Virginia Pinniped Tagging Project � 2018
Data Dates: 2/4/2018-6/14/2018
Data Description: Raw Argos CSV with deployed location data for 7 tagged Pv; Animal and Tag metadata MS Excel spreadsheet;  Point shapefile containing unfiltered movebank export (DF outliers marker as Outlie_Al=1); Line shapefile crated from filtered points
